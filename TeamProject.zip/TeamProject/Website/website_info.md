
1. pip install flask
2. pip install flask-login 
3. pip pip install flask-sqlalchemy
    